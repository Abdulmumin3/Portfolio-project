import React from 'react'

const About = () => {
  return (
    <div>About Mu'min</div>
  )
}

export default About