import React from 'react'
import Services from './Services'
import linkedin from '../components/Assets/linkedin.png'
import twitter from '../components/Assets/twitter.png'
import './ServicesRend.css'

const Homepage = () => {
  return (
    <div className='container'>
      <div className="homepage">
        <header>
        <nav>
          <nav className="navleft">
          <h3>Adesoye AbdulMu'min.</h3>
          <ul  className="navlist">
          <li className='navli'><a href="">About Me</a></li>
          <li className='navli'><a href="">Services</a></li>
          <li className='navli'><a href="">Projects</a></li>
          <li className='navli'><a href="">Contact Me</a></li>
          </ul>
          </nav>
          <div className="imgdiv"><img src={linkedin} alt="linkedin"/>
          <img src={twitter} alt="twitter"/></div>
          
        </nav>
        </header>
        <div className='text'>
        <h3>HI THERE </h3>
        <h3>I am Adesoye AbdulMu'min</h3>
        <h1>A Full-Stack Developer, <br/>Scholar and Mentor.</h1>
        <img src={linkedin} alt="linkedin"/>
        <img src={twitter} alt="twitter"/>
        </div>
      </div>

       {/* <Services/> */}
    </div>
    
  )
}

export default Homepage