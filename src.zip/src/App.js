import React from 'react';
import './App.css';
import Homepage from './pages/Homepage';
import Services from './pages/Services';


function App() {
  return (
    <div className="App">
      {/* <Services/> */}
      <Homepage/>
    </div>

  );
}

export default App;
